%% ELEN 050L (Electric Circuits I): Project 2, Problem 5, Your Name
%
% <<ELEN050L_Project_2_figure_02.png>>
%
% <<ELEN050L_Project_2_Problem_05.png>>
%
% *Hard Copy Deliverables:*
%
% # A MATLAB script and publish the solution using MATLAB's *publish*
% feature.
% # Turn in MATLAB scripts and a document of the run-time results.
% # Turn in the Excel file with the measured results.
%
%% Initialize MATLAB Environment
%

clear; clc; clf; cla; close all;
format short; format compact;


% These values are used for plotting purposes.
fignum = 0;

%% Problem 7
%
% <<ELEN050L_Project_2_Problem_07.png>>
%

% Define the standard component values 
R1 = ?;             % Ohms
R2 = ?;             % Ohms
C1 = ?;             % Farads
C2 = ?;             % Farads

% Target design criteria
A_0_target = 10;     w_0 = 0;        % Amplitude (unitless) at rad/sec
A_1_target = ?;      w_1 = 10000;    % Amplitude (unitless) at rad/sec

% Specify the w variable for characterzation purposes
w = [1:1:10^3,10^3+1:10:2.5e5];

% Shortened version of Apendix 3 function F = freqresp2(Rl,R2,C,w)
den = R1*(sqrt(1+(w.*R2.*C2).^2));
num = R2*(sqrt(1+(w.*R1.*C1).^2));
% In this case, the numerator is a function of the frequency.
A = ?./?;
% The command ./ divides each element of vector num by the
% corresponding element of vector den. As a result, the elements
% of A represent the amplitude at different frequencies.

F = 20*log10(?);
% This is necessary in order to represent the amplitude in decibels.

% Generate the plot for the actual design.
fignum = fignum+1; figObj = figure(fignum);   % Establish a figure number
set(fignum, 'Name', ['Problem 5 A(w)']);      % Name the figure
semilogx(?, ?); grid on;
ylabel('Amplitude (dB)');
xlabel('Frequency (rad/s)');
axis([min(w), max(w), 0, 25]);
title ('Problem 5 Solution');

%% Problem 7 actual design verification point 1
%

% Calculate the first target design point A(w).
den = ?*(sqrt(1+(w_0*?.*?).^2));
num = ?*(sqrt(1+(?*?.*?).^2));
% In this case, the numerator is a function of the frequency.
A_0_design = num./den;

% Calculate the percent difference for the first target design point A(w).
diff_0 = (? - ?)/(?)*?;
fprintf('\nTarget A(%-6.1f) = %-6.4f .\n', ?, ?);
fprintf('\nDesign A(%-6.1f) = %-6.4f .\n', ?, ?);
fprintf('\n%%diff = %-6.4f .\n', ?);

%% Problem 7 actual design verification point 2
%

% Calculate the second target design point A(w).
den = ?*(sqrt(1+(w_1*?.*?).^2));
num = ?*(sqrt(1+(?*?.*?).^2));
% In this case, the numerator is a function of the frequency.
A_1_design = ?./?;

% Calculate the percent difference for the second target design point A(w).
diff_1 = (? - ?)/(?)*?;
fprintf('\nTarget A(%-6.1f) = %-6.4f .\n', ?, ?);
fprintf('\nDesign A(%-6.1f) = %-6.4f .\n', ?, ?);
fprintf('\n%%diff = %-6.4f .\n', ?);

%% Problem 8
%
% <<ELEN050L_Project_2_Problem_08.png>>
%

% Import Excel measurements for Problem 5
[freq_meas,Vg_meas_5,Vo_meas_5] = importfile_problem5...
    ('ELEN050L_Project_2_Problem_5_Measured_Results.xlsx','Sheet1',2,80);

% Define measured values for the circuit elements.
R1_meas = ?;                  % Ohms
R2_meas = ?;                  % Ohms
C1_meas = ?;                  % Farads
C2_meas = ?;                  % Farads
Vcc_p_meas = ?;               % Volts
Vcc_n_meas = ?;               % Volts

% Calculate A_meas(w) using the measured data.
A_meas = ?./?;
% Convert A_meas(w) to decibels.
F_meas = 20*log10(?);
% Convert frequency in Hertz to radians/second.
w_meas = ?*?*?;

% Generate the plot for the measured actual design.
fignum = fignum+1; figObj = figure(fignum);   % Establish a figure number
set(fignum, 'Name', ['Problem 5 A_meas(w)']); % Name the figure
semilogx(?, ?); grid on;
ylabel('Amplitude (dB)');
xlabel('Frequency (rad/s)');
axis([min(w_meas), max(w_meas), 0, 25]);
title ('Problem 5 Solution (Measured)');

%% Problem 8 measured design verification point 1
%

% Extract the first target design point A_meas(w).
A_0_measured = A_meas(1);

% Calculate the percent difference for the first measured design point
% A_meas(w).
diff_0_meas = (? - ?)/(?)*?;
fprintf('\nMeasured A(%-6.1f) = %-6.4f .\n', w_meas(?), ?);
fprintf('\nDesign A(%-6.1f) = %-6.4f .\n', ?, ?);
fprintf('\n%%diff_meas = %-6.4f .\n', ?);

%% Problem 8 measured design verification point 2
%

% Extract the second target design point A_meas(w).
A_1_measured = A_meas(37);

% Calculate the percent difference for the second measured design point
% A_meas(w).
diff_1_meas = (? - ?)/(?)*?;
fprintf('\nMeasured A(%-6.1f) = %-6.4f .\n', w_meas(?), ?);
fprintf('\nDesign A(%-6.1f) = %-6.4f .\n', ?, ?);
fprintf('\n%%diff_meas = %-6.4f .\n', ?);

%% Program execution complete
%

display(' ');
disp('Program execution complete....');

%% MATLAB code listing
%