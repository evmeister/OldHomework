#include <stdint.h>

//This function computes and returns the discriminant.

int32_t disc(int32_t a, int32_t b, int32_t c)
	{
	return b*b - 4*a*c ;
	}
