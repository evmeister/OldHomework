/*Evan Eberhardt
 * 7 February 2017
 * COEN175L T1415
 * Type.cpp
 */

#include "type.h"
#include <ostream>
#include <vector>
using namespace std;

Type::Type(kind _kind, int specifier, unsigned indirection)
	:_kind(_kind),specifier(specifier),indirection(indirection){};

kind Type::getKind() const {return _kind;}
int Type::getSpec() const {return specifier;}
unsigned Type::getInd() const {return indirection;}

void Type::setKind(kind k) {_kind=k;}
void Type::setSpec(int s) {specifier=s;}
void Type::setInd(unsigned i) {indirection=i;}

bool Type::operator==(const Type &that) const {
	if(_kind!=that._kind)
		return false;
	if(specifier!=that.specifier)
		return false;
	if(indirection!=that.indirection)
		return false;
	return true;
}
bool Type::operator!=(const Type &that) const {return !(*this==that);}

ostream &operator<<(ostream &ostr, const Type &type){
	ostr<<type.getKind()<<" of type "<<type.getSpec()<<" and indirection"<<type.getInd();
	if(type.getKind()==ARRAY)
		ostr<<" and length "<<type.length<<endl;
	else if(type.getKind()==FUNCTION)
		if(type._parameters.empty())
			ostr<<" and no indicated parameters"<<endl;
		else{
			ostr<<" and parameters: ";
			for(unsigned n=0; n<type._parameters.size(); n++)
				ostr<<n<<" ";
		}
	ostr<<endl;
	return ostr;
}
