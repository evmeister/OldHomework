/* hello.c */

int main(void)
{
    printf("Hello, world.\n");
}
