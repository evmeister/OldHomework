/*Evan Eberhardt
 * 7 Februaray 2017
 * COEN175L R1415
 * checker.h
 */

#ifndef CHECKER_H
#define CHECKER_H

//Scoping functions-changes current scope
void openGlobal();//Global
void closeGlobal();
void openFunction();//Functions
void closeFunction();
void openBlock();//Blocks
void closeBlock();

//Declaration and Definition functions-creates symbols
void declareVar(string,TYPE);//Scalars and arrays
void declareFunction(string,TYPE,vector);//Functions
void defineFunction(string,TYPE,vector);
	//if prev declared then if match then flip remove old sym and replace

//Symbol use function-checks for errors
void usingVar(string);//scalars and arrays
void usingFunction(string);//functions

#endif /*CHECKER_H*/
