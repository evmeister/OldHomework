/*Evan Eberhardt
 * 7 February 2017
 * COEN175L T1415
 * type.h
 */

#ifndef TYPE_H
#define TYPE_H

#include <vector>
#include <ostream>
using namespace std;

enum kind{SCALAR, ARRAY, FUNCTION};
typedef vector<class Type> Parameters;

class Type{
	//Private variables
	kind _kind;
	int specifier;
	unsigned indirection;
public:
	//Public Variables
	unsigned length;
	Parameters _parameters;

	//Constructor requiring the private variables - Public vars can be default
	Type(kind _kind, int specifier, unsigned indirection=0);
	//Using defualt destructor

	//Accessors
	kind getKind() const;
	int getSpec() const;
	unsigned getInd() const;

	//Mutators
	void setKind(kind);
	void setSpec(int);
	void setInd(unsigned);

	//Operators
	bool operator==(const Type &that) const;
	bool operator!=(const Type &that) const;
};
ostream &operator<<(ostream &ostr, const Type &type);

#endif /*TYPE_H*/
