/*
 * File:	checker.cpp
 *
 * Description:	This file contains the public and private function and
 *		variable definitions for the semantic checker for Simple C.
 *
 *		If a symbol is redeclared, the existing declaration is
 *		retained and the redeclaration discarded.  This behavior
 *		seems to be consistent with GCC, and who are we to argue
 *		with GCC?
 *
 *		Extra functionality:
 *		- inserting an undeclared symbol with the error type
 */

# include <iostream>
# include "lexer.h"
# include "checker.h"
# include "nullptr.h"
# include "tokens.h"
# include "Symbol.h"
# include "Scope.h"
# include "Type.h"

# define FUNCDEFN 1


using namespace std;

static Scope *outermost, *toplevel;
static const Type error;

//*Eberhardt added
static const Type integer(INT);

static string invalidreturn = "invalid return type"; //E1
static string invalidtype = "invalid type for test expression"; //E2
static string lvaluer =  "lvalue required in expression"; //E3
static string invalidoperands = "invalid operands to binary %s"; //E4
static string invalidoperand = "invalid operand to unary %s"; //E5
static string notfunction = "called object is not a function"; //E6
static string invalidargs = "invalid arguments to called function"; //E7
// */

static string redefined = "redefinition of '%s'";
static string redeclared = "redeclaration of '%s'";
static string conflicting = "conflicting types for '%s'";
static string undeclared = "'%s' undeclared";
static string void_object = "'%s' has type void";

//*Eberhardt added

/*
 * check logical or
 */
Type checkLogicalOR(const Type &left, const Type &right){
	//cout<<left<<"||"<<right<<endl;
	if((left == error) || (right == error)) return error;
	if(!left.promote().isPredicate() || !right.promote().isPredicate()){
		report(invalidoperands, "||");
		return error;
	}
	return integer;
}// check logical or */


/*
 * check logical and
 */
Type checkLogicalAND(const Type &left, const Type &right){
	//cout<<left<<"&&"<<right<<endl;
	if((left == error) || (right == error)) return error;
	if(!left.promote().isPredicate() || !right.promote().isPredicate()){
		report(invalidoperands, "&&");
		return error;
	}
	return integer;
}// check logical and */

/*
 * check equality neq
 */
Type checkEqualityNEQ(const Type &left, const Type &right){
	//cout<<left<<"!="<<right<<endl;
	if((left == error) || (right == error)) return error;
	if(!left.isCompatibleWith(right)){
		report(invalidoperands, "!=");
		return error;
	}
	return integer;
}//check equality neq */


/*
 * check equality eql
 */
Type checkEqualityEQL(const Type &left, const Type &right){
	//cout<<left<<"=="<<right<<endl;
	if((left == error) || (right == error)) return error;
	if(!left.isCompatibleWith(right)){
		report(invalidoperands, "==");
		return error;
	}
	return integer;
}// check equality eql */


/*
 * check relation geq
 */
Type checkRelationalGEQ(const Type &left, const Type &right){
	//cout<<left<<">="<<right<<endl;
	if((left == error) || (right == error)) return error;
	if(!left.isIdenticalPredicate(right)){
		report(invalidoperands, ">=");
		return error;
	}
	return integer;
}// check relation geq */


/*
 * check relation leq
 */
Type checkRelationalLEQ(const Type &left, const Type &right){
	//cout<<left<<"<="<<right<<endl;
	if((left == error) || (right == error)) return error;
	if(!left.isIdenticalPredicate(right)){
		report(invalidoperands, "<=");
		return error;
	}
	return integer;
}// check relation leq */


/*
 * check relation gtn
 */
Type checkRelationalGTN(const Type &left, const Type &right){
	//cout<<left<<">"<<right<<endl;
	if((left == error) || (right == error)) return error;
	if(!left.isIdenticalPredicate(right)){
		report(invalidoperands, ">");
		return error;
	}
	return integer;
}// check relation gtn */


/*
 * check relation ltn
 */
Type checkRelationalLTN(const Type &left, const Type &right){
	//cout<<left<<"<"<<right<<endl;
	if((left == error) || (right == error)) return error;
	if(!left.isIdenticalPredicate(right)){
		report(invalidoperands, "<");
		return error;
	}
	return integer;
}// check relation ltn */


/*
 * check additive sub
 */
Type checkAdditiveSUB(const Type &left, const Type &right){
	//cout<<left<<"-"<<right<<endl;
	if((left == error) || (right == error)) return error;

	Type lhs = left.promote();
	Type rhs = right.promote();
	if((lhs == integer) && (rhs == integer))
		return integer;
	if((lhs.isPointer() && !lhs.isPointerToVoid()) && (rhs == integer))
		return Type(lhs.specifier(), lhs.indirection() + 1);

	if(rhs.isPointer() && lhs.isPointer() && (!lhs.isPointerToVoid()) && (!rhs.isPointerToVoid()) && 
			(lhs.specifier() == rhs.specifier()))
		return integer;
				
	report(invalidoperands,"-");
	return error;
}// check additive sub */


/*
 * check additive add
 */
Type checkAdditiveADD(const Type &left, const Type &right){
	//cout<<left<<"+"<<right<<endl;
	if((left == error) || (right == error)) return error;
	
	Type lhs = left.promote();
	Type rhs = right.promote();
	if((lhs == integer) && (rhs == integer))
	   	return integer;
	if((lhs.isPointer() && !lhs.isPointerToVoid()) && (rhs == integer))
		return Type(lhs.specifier(), lhs.indirection() + 1);

	if((rhs.isPointer() && !rhs.isPointerToVoid()) && (lhs == integer))
		return Type(rhs.specifier(), rhs.indirection() + 1);

	report(invalidoperands, "+");
	return error;
}// check additive add */


/*
 * check multiply rem
 */
Type checkMultiplicativeREM(const Type &left, const Type &right){
	//cout<<left<<"%"<<right<<endl;
	if((left == error) || (right == error)) return error;
	if((left != integer) || (right != integer)){
		report(invalidoperands, "%");
		return error;
	}
	return integer;
}// check multiply rem */


/*
 * check multiply div
 */
Type checkMultiplicativeDIV(const Type &left, const Type &right){
	//cout<<left<<"/"<<right<<endl;
	if((left == error) || (right == error)) return error;
	if((left != integer) || (right != integer)){
		report(invalidoperands, "/");
		return error;
	}
	return integer;
}// check multiply div */


/*
 * check multiply mul
 */
Type checkMultiplicativeMUL(const Type &left, const Type &right){
	//cout<<left<<"*"<<right<<endl;
	if((left == error) || (right == error)) return error;
	if((left != integer) || (right != integer)){
		report(invalidoperands, "*");
		return error;
	}
	return integer;
}// check multiply mul */


/*
 * check prefix sizeof
 */
Type checkPrefixSIZEOF(const Type &right){
	//cout<<"SIZEOF"<<right<<endl;
	if(right == error) return error;
	if(!right.isPredicate()){
		report(invalidoperand, "SIZEOF");
		return error;
	}
	return integer;
}// check prefix sizeof */

/*
 * check prefix addr
 */
Type checkPrefixADDR(const Type &right, const bool &lvalue){
	//cout<<"&"<<right;
	//if(lvalue) cout<<"lval true"<<endl; else cout<<"lval false"<<endl;
	if(right == error) return error;
	if(lvalue == false){
		report(lvaluer);
		return error;
	}
	return Type(right.specifier(), right.indirection() + 1);
}// check prefix addr */


/*
 * check prefix dref
 */
Type checkPrefixDREF(const Type &right){
	//cout<<"*"<<right<<endl;
	if(right == error) return error;
	if(right.promote().isPointerToVoid() || !right.promote().isPointer()){
		report(invalidoperand, "*");
		return error;
	}
	return Type(right.specifier(), right.indirection() - 1);
}// check prefix dref


/*
 * check prefix neg
 */
Type checkPrefixNEG(const Type &right){
	//cout<<"-"<<right<<endl;
	if(right == error) return error;
	if(right != integer){
		report(invalidoperand, "-");
		return error;
	}
	return integer;
}// check prefix neg


/*
 * check prefix not
 */
Type checkPrefixNOT(const Type &right){
	//cout<<"!"<<right<<endl;
	if(right == error) return error;
	if(!right.isPredicate()){
		report(invalidoperand, "!");
		return error;
	}
	return integer;
}// check prefix not


/*
 * check postfix array
 */
Type checkPostfix(const Type &left, const Type &right){
	//cout<<"array"<<left<<"["<<right<<"]"<<endl;
	if((left == error) || (right == error)) return error;
	if(left.promote().isPointerToVoid() || !left.promote().isPointer() || (right != integer)){
		report(invalidoperands, "[]");
		return error;
	}
	return Type(left.specifier());
}// check postfix array


/*
 * check function call
 */
Type checkFunctionCall(const Type &type, const Parameters *args){
	//cout<<"function"<<type<<"args";
	//for(int i = 0; i < args->size(); i++) cout<< args[i] <<endl;
	if(type == error) return error;

	if(!type.isFunction()){
		report(notfunction);
		return error;
	}
	
	Parameters *provided = type.parameters();

	if(provided == NULL){
		report(notfunction);
		return error;
	}

	int psize = provided->size();
	if(psize != (int)args->size()){
		report(invalidargs);
		return error;
	}
	for(unsigned i = 0; i < psize; i++){
		Type lhs = provided->at(i);
		Type rhs = args->at(i);
		if(!(rhs.isPredicate() && lhs.isCompatibleWith(rhs))){
			report(invalidargs);
			return error;
		}
	}

	return Type(type.specifier());
}

	/*
	if(!type.hasValidArgs(*args)){
		report(invalidargs);
		return error;
	}
	return Type(type.specifier());
}// check function call */

void checkReturn(const Type &type, const Type &returned){
	if(!type.isCompatibleWith(returned)){
		report(invalidreturn);
	}
}
void checkWhile(const Type &type){
	if(!type.isPredicate())
		report(invalidtype);
}
void checkIf(const Type &type){
	if(!type.isPredicate())
		report(invalidtype);
}
void checkFor(const Type &type){
	if(!type.isPredicate())
		report(invalidtype);
}
void checkAssignment(const Type &left, const Type &right, bool &lvalue){
	if((left == error) || (right == error)) return;
	if(lvalue == false)
		report(lvaluer);
	else if(!left.isCompatibleWith(right))
		report(invalidoperands, "=");
}

//--/



/*
 * Function:	checkIfVoidObject
 *
 * Description:	Check if TYPE is a proper use of the void type (if the
 *		specifier is void, then the indirection must be nonzero or
 *		the kind must be a function).  If the type is proper, it is
 *		returned.  Otherwise, the error type is returned.
 */

static Type checkIfVoidObject(const string name, const Type &type)
{
    if (type.specifier() != VOID)
	return type;

    if (type.indirection() == 0 && !type.isFunction()) {
	report(void_object, name);
	return error;
    }

    return type;
}


/*
 * Function:	openScope
 *
 * Description:	Create a scope and make it the new top-level scope.
 */

Scope *openScope()
{
    toplevel = new Scope(toplevel);

    if (outermost == nullptr)
	outermost = toplevel;

    return toplevel;
}


/*
 * Function:	closeScope
 *
 * Description:	Remove the top-level scope, and make its enclosing scope
 *		the new top-level scope.
 */

Scope *closeScope()
{
    Scope *old = toplevel;
    toplevel = toplevel->enclosing();
    return old;
}


/*
 * Function:	defineFunction
 *
 * Description:	Define a function with the specified NAME and TYPE.  A
 *		function is always defined in the outermost scope.
 */

Symbol *defineFunction(const string &name, const Type &type)
{
    Symbol *symbol = declareFunction(name, type);

    if (symbol->_attributes & FUNCDEFN)
	report(redefined, name);

    symbol->_attributes = FUNCDEFN;
    return symbol;
}


/*
 * Function:	declareFunction
 *
 * Description:	Declare a function with the specified NAME and TYPE.  A
 *		function is always declared in the outermost scope.  Any
 *		redeclaration is discarded.
 */

Symbol *declareFunction(const string &name, const Type &type)
{
    cout << name << ": " << type << endl;
    Symbol *symbol = outermost->find(name);

    if (symbol == nullptr) {
	symbol = new Symbol(name, type);
	outermost->insert(symbol);

    } else if (type != symbol->type()) {
	report(conflicting, name);
	delete type.parameters();

    } else
	delete type.parameters();

    return symbol;
}


/*
 * Function:	declareVariable
 *
 * Description:	Declare a variable with the specified NAME and TYPE.  Any
 *		redeclaration is discarded.
 */

Symbol *declareVariable(const string &name, const Type &type)
{
    cout << name << ": " << type << endl;
    Symbol *symbol = toplevel->find(name);

    if (symbol == nullptr) {
	symbol = new Symbol(name, checkIfVoidObject(name, type));
	toplevel->insert(symbol);

    } else if (outermost != toplevel)
	report(redeclared, name);

    else if (type != symbol->type())
	report(conflicting, name);

    return symbol;
}


/*
 * Function:	checkIdentifier
 *
 * Description:	Check if NAME is declared.  If it is undeclared, then
 *		declare it as having the error type in order to eliminate
 *		future error messages.
 */

Symbol *checkIdentifier(const string &name)
{
    Symbol *symbol = toplevel->lookup(name);

    if (symbol == nullptr) {
	report(undeclared, name);
	symbol = new Symbol(name, error);
	toplevel->insert(symbol);
    }

    return symbol;
}


/*
 * Function:	checkFunction
 *
 * Description:	Check if NAME is a previously declared function.  If it is
 *		undeclared, then implicitly declare it.
 */

Symbol *checkFunction(const string &name)
{
    Symbol *symbol = toplevel->lookup(name);

    if (symbol == nullptr)
	symbol = declareFunction(name, Type(INT, 0, nullptr));

    return symbol;
}
